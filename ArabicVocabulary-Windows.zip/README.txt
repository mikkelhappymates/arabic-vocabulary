# Arabic Vocabulary - Windows Version

A desktop application for learning Arabic vocabulary with Danish and English translations.

## Requirements

- Windows 10 or later (64-bit)
- Python 3.10 or later (https://www.python.org/downloads/)

## Installation

1. Extract this ZIP file to a folder of your choice

2. Install Python 3.10+ from https://www.python.org/downloads/
   - IMPORTANT: Check "Add Python to PATH" during installation

3. Open a terminal in the extracted folder and install dependencies:
   
   pip install -r requirements.txt

4. Run the application:
   
   python main.py

## Dependencies

The application requires the following Python packages:
- PyQt6 (Qt6 GUI framework)

These will be installed automatically when you run: pip install -r requirements.txt

## Features

- Arabic Word Storage - Store Arabic words with transliteration, English, and Danish translations
- Built-in Arabic Keyboard - Virtual keyboard with full Arabic alphabet and diacritics  
- Tag System - Organize words with custom tags
- Search & Filter - Find words quickly
- Dark Mode - Arabic-inspired dark theme

## Data Storage

Your vocabulary is saved locally at:
C:\Users\<YourName>\Documents\ArabicVocabulary\vocabulary.json

This folder is created automatically on first launch.

## Troubleshooting

### Python not found
- Make sure Python is installed and added to PATH
- Try running: py main.py (instead of python main.py)

### PyQt6 DLL errors
- Reinstall PyQt6: pip uninstall PyQt6 PyQt6-Qt6 PyQt6-sip && pip install PyQt6

### Arabic text not displaying
- The application uses built-in fonts; no additional fonts required

## Source Code

https://github.com/mikkelhappymates/arabic-vocabulary
